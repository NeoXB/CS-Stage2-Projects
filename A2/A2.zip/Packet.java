/*
 *	============================================================================================
 *	Packet.java :  takes a string object as a parameter and it sets up a Packet object.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	============================================================================================
 */
 
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.util.regex.*;

public class Packet {
    private String src;
    private String dest;
    private double time;
    private int size;
    public Packet(String p) {
        String[] packetArray = p.split("\\t{1}");
        if (packetArray.length >= 8) {
            time = Double.parseDouble(packetArray[1]);
            src = packetArray[2];
            dest = packetArray[4];
            size = Integer.parseInt(packetArray[7]);
        } else if (packetArray.length == 5) {
            time = Double.parseDouble(packetArray[1]);
            src = packetArray[2];
            dest = packetArray[4];
        } else if (packetArray.length == 3) {
            time = Double.parseDouble(packetArray[1]);
            src = packetArray[2];
            dest = "";
        } else {
            time = Double.parseDouble(packetArray[1]);
            src = "";
            dest = "";
        }
    }
    public String getSourceHost() {
        return src;
    }
    public String getDestinationHost() {
        return dest;
    }
    public double getTimeStamp() {
        return time;
    }
    public int getIpPacketSize() {
        return size;
    }
    public void setSourceHost(String src) {
        this.src = src;
    }
    public void setDestinationHost(String dest) {
        this.dest = dest;
    }
    public void setTimeStamp(double time) {
        this.time = time;
    }
    public void setIpPacketSize(int size) {
        this.size = size;
    }
    public String toString() {
        String newTime = String.format("%.2f", time);
        String s = "src=" + src + ", dest=" + dest + ", time=" + newTime + ", size=" + size;
        return s;
    }
}