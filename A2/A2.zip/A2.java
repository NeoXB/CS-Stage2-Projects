/*
 *	============================================================================================
 *	A2.java : Extends JFrame and it is an application that displays the trace file(s) from the 
 *  Auckland Satellite Simulator in tabular form.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	============================================================================================
 */

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.util.regex.*;
import javax.swing.table.*;

public class A2 extends JFrame {
	private JPanel buttonPanel, tablePanel;
	private JRadioButton srcHost, destHost;
	private ButtonGroup buttonGroup;
	private JComboBox<Host> comboBox;
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem m1, m2, m3;
	private JFileChooser fileChooser;
	private Simulator simulator;
	private File file;
	private Host[] hosts;
	private JScrollPane buttonPane, tablePane;
	private boolean isSrcHost = true;
	private boolean fileChosen = false;
	private JTable table;
	private Packet[] packets;
	private PacketTableModel ptm;
	private boolean hasTable = false;
	
	/** main method for A1
	 */
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new A2();
			}
		});
	}
	
	/** constructor to initialise components
	 */
	public A2() {
		super("A2");
		a2MenuBar();
		setLayout(new BorderLayout());
		// add button panel to frame
		// button panel contains the two radio buttons and the combo box
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		srcHost = new JRadioButton("Source Hosts");
		destHost = new JRadioButton("Destination Hosts");
		buttonGroup = new ButtonGroup();
		buttonGroup.add(srcHost);
		buttonGroup.add(destHost);
		buttonPanel.add(srcHost);
		buttonPanel.add(destHost);
		srcHost.setSelected(true);
		comboBox = new JComboBox<Host>();
		comboBox.setPreferredSize(new Dimension(230,25));
		buttonPane = new JScrollPane();
		comboBox.add(buttonPane);
		comboBox.setVisible(false);
		buttonPanel.add(comboBox);
		add(buttonPanel,BorderLayout.NORTH);
		// add table panel to frame
		tablePanel = new JPanel();
		add(tablePanel,BorderLayout.CENTER);
		tablePanel.setVisible(false);
		// continue setting up frame
		setSize(500,550);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
		String currentDirectory = System.getProperty("user.dir");
		fileChooser = new JFileChooser(currentDirectory);
		// "Open trace file" button action listener
		m1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				fileChooser.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						fileChosen = true;
						tablePanel.setVisible(true);
						file = fileChooser.getSelectedFile();
						simulator = new Simulator(file);
						if (isSrcHost) {
							// set up combo box
							comboBox.removeAllItems();
							hosts = simulator.getUniqueSortedSourceHosts();
							for (Host h : hosts) {
								comboBox.addItem(h);
							}
							comboBox.setVisible(true);
							// set up table
							if (hasTable) {
								tablePanel.remove(tablePane);
								String firstHost = hosts[0].toString();
								packets = simulator.getTableData(firstHost, isSrcHost);
								ptm = new PacketTableModel(packets, isSrcHost);
								// render cell background color
								table = new JTable(ptm) {
									public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
										Component c = super.prepareRenderer(renderer, row, col);
										if (row > ptm.getRowCount()-3) {
											c.setBackground(Color.GREEN);
										} else {
											c.setBackground(Color.YELLOW);
										}
										return c;
									}
								};
								// render cell alignment
								DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
								centerRender.setHorizontalAlignment(JLabel.CENTER);
								for (int i = 0; i < ptm.getColumnCount(); i++) {
									table.getColumnModel().getColumn(i).setCellRenderer(centerRender);
								}
								tablePane = new JScrollPane(table);
								tablePanel.add(tablePane);
							} else {
								String firstHost = hosts[0].toString();
								packets = simulator.getTableData(firstHost, isSrcHost);
								ptm = new PacketTableModel(packets, isSrcHost);
								// render cell background color
								table = new JTable(ptm) {
									public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
										Component c = super.prepareRenderer(renderer, row, col);
										if (row > ptm.getRowCount()-3) {
											c.setBackground(Color.GREEN);
										} else {
											c.setBackground(Color.YELLOW);
										}
										return c;
									}
								};
								// render cell alignment
								DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
								centerRender.setHorizontalAlignment(JLabel.CENTER);
								for (int i = 0; i < ptm.getColumnCount(); i++) {
									table.getColumnModel().getColumn(i).setCellRenderer(centerRender);
								}
								tablePane = new JScrollPane(table);
								tablePanel.add(tablePane);
								hasTable = true;
							}
						} else {
							// set up combo box
							comboBox.removeAllItems();
							hosts = simulator.getUniqueSortedDestHosts();
							for (Host h : hosts) {
								comboBox.addItem(h);
							}
							comboBox.setVisible(true);
							// set up table
							if (hasTable) {
								tablePanel.remove(tablePane);
								String firstHost = hosts[0].toString();
								packets = simulator.getTableData(firstHost, isSrcHost);
								ptm = new PacketTableModel(packets, isSrcHost);
								// render cell background color
								table = new JTable(ptm) {
									public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
										Component c = super.prepareRenderer(renderer, row, col);
										if (row > ptm.getRowCount()-3) {
											c.setBackground(Color.GREEN);
										} else {
											c.setBackground(Color.YELLOW);
										}
										return c;
									}
								};
								// render cell alignment
								DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
								centerRender.setHorizontalAlignment(JLabel.CENTER);
								for (int i = 0; i < ptm.getColumnCount(); i++) {
									table.getColumnModel().getColumn(i).setCellRenderer(centerRender);
								}
								tablePane = new JScrollPane(table);
								tablePanel.add(tablePane);
							} else {
								String firstHost = hosts[0].toString();
								packets = simulator.getTableData(firstHost, isSrcHost);
								ptm = new PacketTableModel(packets, isSrcHost);
								// render cell background color
								table = new JTable(ptm) {
									public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
										Component c = super.prepareRenderer(renderer, row, col);
										if (row > ptm.getRowCount()-3) {
											c.setBackground(Color.GREEN);
										} else {
											c.setBackground(Color.YELLOW);
										}
										return c;
									}
								};
								// render cell alignment
								DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
								centerRender.setHorizontalAlignment(JLabel.CENTER);
								for (int i = 0; i < ptm.getColumnCount(); i++) {
									table.getColumnModel().getColumn(i).setCellRenderer(centerRender);
								}
								tablePane = new JScrollPane(table);
								tablePanel.add(tablePane);
								hasTable = true;
							}
						}
					}
				});
				int dialogWindow = fileChooser.showOpenDialog(null);
			}	
		});
		// "Quit" button action listener
		m2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
                System.exit(0);
			}
		});
		// "Source Host" button mouse listener
		srcHost.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (fileChosen) {
                    isSrcHost = true;
					// set up combo box
					comboBox.removeAllItems();
					hosts = simulator.getUniqueSortedSourceHosts();
					for (Host h : hosts) {
						comboBox.addItem(h);
					}
					// set up table
					tablePanel.remove(tablePane);
					String firstHost = hosts[0].toString();
					packets = simulator.getTableData(firstHost, isSrcHost);
					ptm = new PacketTableModel(packets, isSrcHost);
					// render cell background color
					table = new JTable(ptm) {
						public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
							Component c = super.prepareRenderer(renderer, row, col);
							if (row > ptm.getRowCount()-3) {
								c.setBackground(Color.GREEN);
							} else {
								c.setBackground(Color.YELLOW);
							}
							return c;
						}
					};
					// render cell alignment
					DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
					centerRender.setHorizontalAlignment(JLabel.CENTER);
					for (int i = 0; i < ptm.getColumnCount(); i++) {
						table.getColumnModel().getColumn(i).setCellRenderer(centerRender);
					}
					tablePane = new JScrollPane(table);
					tablePanel.add(tablePane);
				} else {
					isSrcHost = true;
				}
            }
        });
		// "Destination Host" button mouse listener
		destHost.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (fileChosen) {
                    isSrcHost = false;
					// set up combo box
					comboBox.removeAllItems();
					hosts = simulator.getUniqueSortedDestHosts();
					for (Host h : hosts) {
						comboBox.addItem(h);
					}
					// set up table
					tablePanel.remove(tablePane);
					String firstHost = hosts[0].toString();
					packets = simulator.getTableData(firstHost, isSrcHost);
					ptm = new PacketTableModel(packets, isSrcHost);
					// render cell background color
					table = new JTable(ptm) {
						public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
							Component c = super.prepareRenderer(renderer, row, col);
							if (row > ptm.getRowCount()-3) {
								c.setBackground(Color.GREEN);
							} else {
								c.setBackground(Color.YELLOW);
							}
							return c;
						}
					};
					// render cell alignment
					DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
					centerRender.setHorizontalAlignment(JLabel.CENTER);
					for (int i = 0; i < ptm.getColumnCount(); i++) {
						table.getColumnModel().getColumn(i).setCellRenderer(centerRender);
					}
					tablePane = new JScrollPane(table);
					tablePanel.add(tablePane);
				} else {
					isSrcHost = false;
				}
            }
        });
	}
	
	/** create the menu bar for the application
	 * @param	null
	 * @return	null
	 */
	public void a2MenuBar() {
		menuBar = new JMenuBar();
		menu = new JMenu("File");
		m1 = new JMenuItem("Open trace file");
		m2 = new JMenuItem("Quit");
		m3 = new JMenuItem("Save");
		menu.add(m1);
		menu.add(m2);
		menu.add(m3);
		menuBar.add(menu);
		setJMenuBar(menuBar);
	}
}




