/*
 *	============================================================================================
 *	Host.java :  implements the Comparable<Host> interface and it sets up a Host object.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	============================================================================================
 */
 
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.util.regex.*;

public class Host implements Comparable<Host> {
    private String ip;
    public Host(String ip) {
        this.ip = ip;
    }
    public String toString() {
        return ip;
    }
    public int compareTo(Host other) {
        String[] lastDigits1 = ip.split("\\.", 4);
        String[] lastDigits2 = other.ip.split("\\.", 4);
        int ip1 = Integer.parseInt(lastDigits1[3]);
        int ip2 = Integer.parseInt(lastDigits2[3]);
        return ip1 - ip2;
    }
}