/*
 *	============================================================================================
 *	Simulator.java : takes a File object as a parameter and reads the content in the text file
 *  to create an ArrayList of valid Packet objects. A valid packet must contain a valid IP 
 *  address of IP version 4 (IPv4).
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	============================================================================================
 */
 
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.util.regex.*;

public class Simulator {
    private ArrayList<Packet> packets = new ArrayList<Packet>();
	/** constructor to initialise components
	 * @param	file		the filename of the trace file
	 */
    public Simulator(File file) {
        try {
            BufferedReader r = new BufferedReader(new FileReader(file));
            String newline = r.readLine();
            while (newline != null) {
                Packet p = new Packet(newline);
                String regExpStr = "^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$"; //complete this
                Pattern pattern = Pattern.compile(regExpStr);
                Matcher matcher1 = pattern.matcher(p.getSourceHost());
                Matcher matcher2 = pattern.matcher(p.getDestinationHost());
                if (matcher1.matches() && matcher2.matches()) {
                    packets.add(p);
                }
                newline = r.readLine();
            }
            r.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
	/** return the ArrayList of valid Packet Objects
	 * @return	packets		ArrayList of valid Packet Objects
	 */
    public ArrayList<Packet> getValidPackets() {
        return packets;
    }
	/**  return an array of source hosts. All Host objects must 
	 *   contains valid IP addresses of IP version 4 (IPv4). The array must 
	 *   only contains unique and sorted IP addresses.
	 * @return hosts	array of type Host	
	 */
    public Host[] getUniqueSortedSourceHosts() {
        ArrayList<String> uniqueHosts = new ArrayList<String>();
        for (Packet p : packets) {
            if (!uniqueHosts.contains(p.getSourceHost())) {
                uniqueHosts.add(p.getSourceHost());
            }
        } 

        int totalPackets = uniqueHosts.size();
        Host[] hosts = new Host[totalPackets];
        for (int i = 0; i < totalPackets; i++) {
            Host h = new Host(uniqueHosts.get(i));
            hosts[i] = h;
        }
        Arrays.sort(hosts);
        return hosts;
    }
	/**  return an array of destination hosts. All Host objects must 
	 *   contains valid IP addresses of IP version 4 (IPv4). The array must 
	 *   only contains unique and sorted IP addresses.
	 * @param	filename		the filename of the image
	 * @return ImageIcon		the imageIcon
	 */
    public Host[] getUniqueSortedDestHosts() {
        ArrayList<String> uniqueHosts = new ArrayList<String>();
        for (Packet p : packets) {
            if (!uniqueHosts.contains(p.getDestinationHost())) {
                uniqueHosts.add(p.getDestinationHost());
            }
        } 

        int totalPackets = uniqueHosts.size();
        Host[] hosts = new Host[totalPackets];
        for (int i = 0; i < totalPackets; i++) {
            Host h = new Host(uniqueHosts.get(i));
            hosts[i] = h;
        }
        Arrays.sort(hosts);
        return hosts;
    }
	/** takes an IP address and a isSrcHost (of type boolean) as parameters 
	*   and returns an array of Packet objects. If the boolean is true, the array 
	*   of Packet objects should only contain those packets from the source hosts 
	*   based on the IP address specified in the parameter. If the parameter boolean 
	*   is false, the array of Packet objects should only contains those packets from 
	*   the destination hosts based on the IP address specified in the parameter string.
	* @param	ip					string of ip address
	*			isSrcHost			boolean that checks if ip address given is a source host or not
	* @return   selectedPackets		array of Packet objects.
	*/
    public Packet[] getTableData(String ip, boolean isSrcHost) {
        ArrayList<Packet> checkPackets = new ArrayList<Packet>();
        if (isSrcHost) {
            for (Packet p : packets) {
                if (p.getSourceHost().equals(ip)) {
                    checkPackets.add(p);
                }
            }
            Packet[] selectedPackets = new Packet[checkPackets.size()];
            for (int i = 0; i < checkPackets.size(); i++) {
                selectedPackets[i] = checkPackets.get(i);
            }
            return selectedPackets;
        } else {
            for (Packet p : packets) {
                if (p.getDestinationHost().equals(ip)) {
                    checkPackets.add(p);
                }
            }
            Packet[] selectedPackets = new Packet[checkPackets.size()];
            for (int i = 0; i < checkPackets.size(); i++) {
                selectedPackets[i] = checkPackets.get(i);
            }
            return selectedPackets;
        }
    }
}