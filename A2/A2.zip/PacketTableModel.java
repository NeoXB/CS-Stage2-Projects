/*
 *	============================================================================================
 *	PacketTableModel.java : set up the data model. It also computes the total number of bytes 
 *  (IP packet size) and the average number of bytes across all data rows.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	============================================================================================
 */
 
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.util.regex.*;
import javax.swing.table.*;

public class PacketTableModel extends AbstractTableModel {
    private Packet[] p;
    private boolean isSrcHost;
    private int totalBytes;
    private double aveBytes;
	private String[] COLUMN_NAMES;
	/** constructor to initialise components
	 * @param	p			array of packet objects
	 * 			isSrcHost	boolean to check if ip address is a source host or a destination host
	 */
    public PacketTableModel(Packet[] p, boolean isSrcHost) {
        this.p = p;
        this.isSrcHost = isSrcHost;
        for (Packet packet : p) {
            totalBytes += packet.getIpPacketSize();
        }
        aveBytes = totalBytes / p.length;
		if (isSrcHost) {
			COLUMN_NAMES = new String[]{ "Time Stamp","Source IP Address","Packet Size" };
		} else {
			COLUMN_NAMES = new String[]{ "Time Stamp","Destination IP Address","Packet Size" };
		}
    }
	/** gets column names
	 * @param	col				column index
	 * @return  				column name
	 */
    public String getColumnName(int col) {
        return COLUMN_NAMES[col];
    }
	/** gets column count
	 * @return  			column amount
	 */
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }
	/** gets row count
	 * @return  			row amount
	 */
    public int getRowCount() {
        return p.length + 2;
    }
	/** get value at specific row and column
	 * @param	row, col	row and column indexes respectively
	 * @return  			specified item (either time stamp,
	 *						source host, destination host, 
	 *						ip packet size, sum of all ip packet sizes
	 *						or average of all ip packet sizes)
	 */
    public Object getValueAt(int row, int col) {
        if (row == p.length + 1) {
			if (col == 2) {
				return aveBytes;
			} else {
				return null;
			}
        } else if (row == p.length) {
			if (col == 2) {
				return totalBytes;
			} else {
				return null;
			}
        } else {
            if (col == 2) {
                return p[row].getIpPacketSize();
            } else if (col == 1) {
                if (isSrcHost) {
                    return p[row].getSourceHost();
                } else {
                    return p[row].getDestinationHost();
                }
            } else {
                return p[row].getTimeStamp();
            }
        }
    }
	/** check if cell is editable or not
	 * @param	row, col	row and column indexes respectively
	 * @return  boolean 	is editable or not editable
	 */
	public boolean isCellEditable(int row, int col) {
		if (col != 2) {
			return false;
		} else {
			return true;
		}
	}
	/** set value at specific row and column
	 * @param	row, col		row and column indexes respectively
	 *			newPacketSize	the size of ip packet that we want to be changed
	 */
	public void setValueAt(Object newPacketSize, int row, int col) {
		if (col == 2) {
			try {
				String packetSize = (String) newPacketSize;
				int size = Integer.parseInt(packetSize);
				p[row].setIpPacketSize(size);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		fireTableCellUpdated(row,col);
	}
}