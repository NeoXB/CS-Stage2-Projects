/*
 *	===============================================================================
 *	MovingPixelArt.java : extends MovingSquare.
 *	It represents a pixel-art object (pixelated picture/image).
 *	It overrides the draw() method from MovingSquare.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */

import java.awt.*;
import java.util.*;

public class MovingPixelArt extends MovingSquare {
	private String[] values = {"1111111111", "1111551111", "1111551111", "1115555111", "1115555111", "1155555511", "1555555551", "1111881111", "1111881111", "1111111111"};
	private Color[] colours = {Color.black, Color.white, Color.red, Color.orange, Color.yellow, Color.green, Color.cyan, Color.blue, Color.gray, Color.DARK_GRAY};
    public MovingPixelArt() {
        super();
    }
    public MovingPixelArt(int x, int y, int size, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, size, mw, mh, bc, fc, pathType);
    }
	public void draw(Graphics g) {
		int x1 = x;
		int y1 = y;
		for (String row : values) {
			for (int i = 0; i < row.length(); i++) {
				int colorIndex = Character.getNumericValue(row.charAt(i));
				g.setColor(colours[colorIndex]);
				g.fillRect(x1, y1, width/10, height/10);
				g.drawRect(x1, y1, width/10, height/10);
				x1 += width/10;
			}
			x1 = x;
			y1 += height/10;
		}
	}
}
