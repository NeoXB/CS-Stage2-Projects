/*
 *	===============================================================================
 *	MovingQuadCircles.java : extends MovingCircle.
 *	It represents a quad-circle object (four circles intersecting each other symmetrically).
 *	It overrides the draw() method from MovingCircle.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */

import java.awt.*;
import java.util.*;
import java.awt.geom.*;

public class MovingQuadCircles extends MovingCircle {
    public MovingQuadCircles() {
        super();
    }
    public MovingQuadCircles(int x, int y, int size, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, size, mw, mh, bc, fc, pathType);
    }
	public void draw(Graphics g) {
		Graphics2D mqc = (Graphics2D) g;
		
		Ellipse2D c1 = new Ellipse2D.Double(x + (width/4), y, width/2, height/2);
		Ellipse2D c2 = new Ellipse2D.Double(x + (width/2), y + (height/4), width/2, height/2);
		Ellipse2D c3 = new Ellipse2D.Double(x + (width/4), y + (height/2), width/2, height/2);
		Ellipse2D c4 = new Ellipse2D.Double(x, y + (height/4), width/2, height/2);
		
		Area a1 = new Area(c1);
		Area a2 = new Area(c2);
		Area a3 = new Area(c3);
		Area a4 = new Area(c4);
		Area a5 = new Area(c1);
		
		mqc.setColor(fillColor);
		a1.intersect(a2);
		mqc.fill(a1);
		a2.intersect(a3);
		mqc.fill(a2);
		a3.intersect(a4);
		mqc.fill(a3);
		a4.intersect(a5);
		mqc.fill(a4);
		
		mqc.setColor(borderColor);
		mqc.draw(c1);
		mqc.draw(c2);
		mqc.draw(c3);
		mqc.draw(c4);
	}
}
