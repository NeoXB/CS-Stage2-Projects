/*
 *	===============================================================================
 *	MovingCircle.java : extends MovingEllipse and it is the superclass of MovingQuadCircles.
 *	It represents a circle object.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */
 
import java.awt.*;
import java.util.*;

public class MovingCircle extends MovingEllipse {
    public MovingCircle() {
        super();
    }
    public MovingCircle(int x, int y, int size, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, size, size, mw, mh, bc, fc, pathType);
    }
    public void setWidth(int w) {
        width = w;
        height = w;
    }
    public void setHeight(int h) {
        height = h;
        width = h;
    }
}
