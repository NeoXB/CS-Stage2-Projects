/*
 *	===============================================================================
 *	MovingSquare.java : extends MovingRectangle and it is the superclass of MovingPixelArt.
 *	It represents a square object.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */
 
import java.awt.*;
import java.util.*;

public class MovingSquare extends MovingRectangle {
    public MovingSquare() {
        super();
    }
    public MovingSquare(int x, int y, int size, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, size, size, mw, mh, bc, fc, pathType);
    }
    public void setWidth(int w) {
        width = w;
        height = w;
    }
    public void setHeight(int h) {
        height = h;
        width = h;
    }
}
