/*
 *	===============================================================================
 *	MovingEmoji.java : extends MovingPixelArt.
 *	It represents a pixelated emoji-art object.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */

import java.awt.*;
import java.util.*;

public class MovingEmoji extends MovingPixelArt {
	private String[] values = {"1110000111", "1104444011", "1044444401", "0000000000", "0010010040", "0400400440", "0444444040", "1044400401", "1104444011", "1110000111"};
	private Color[] colours = {Color.black, Color.white, Color.red, Color.orange, Color.yellow, Color.green, Color.cyan, Color.blue, Color.gray, Color.DARK_GRAY};
    public MovingEmoji() {
        super();
    }
    public MovingEmoji(int x, int y, int size, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, size, mw, mh, bc, fc, pathType);
    }
	public void draw(Graphics g) {
		int x1 = x;
		int y1 = y;
		for (String row : values) {
			for (int i = 0; i < row.length(); i++) {
				int colorIndex = Character.getNumericValue(row.charAt(i));
				g.setColor(colours[colorIndex]);
				g.fillRect(x1, y1, width/10, height/10);
				g.drawRect(x1, y1, width/10, height/10);
				x1 += width/10;
			}
			x1 = x;
			y1 += height/10;
		}
	}
}
