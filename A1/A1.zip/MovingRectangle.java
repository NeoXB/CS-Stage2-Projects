/*
 *	===============================================================================
 *	MovingRectangle.java : extends MovingShape and it is the superclass of MovingSquare.
 *	It represents a rectangle object.
 *	It overrides the draw(), getArea() and contains() methods from MovingShape.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */
 
import java.awt.*;
import java.util.*;

public class MovingRectangle extends MovingShape {
    public MovingRectangle() {
        super();
    }
    public MovingRectangle(int defaultSize) {
        super(defaultSize);
    }
    public MovingRectangle(int x, int y, int w, int h, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, w, h, mw, mh, bc, fc, pathType);
    }
    public void draw(Graphics g) {
		g.setColor(fillColor);
        g.fillRect(x, y, width, height);
		g.setColor(borderColor);
		g.drawRect(x, y, width, height);
    }
    public double getArea() {
        double a = width * height;
        return a;
    }
    public boolean contains(Point p) {
        int x1 = x + width;
        int y1 = y + height;
        if (x <= p.x && p.x <= x1) {
            if (y <= p.y && p.y <= y1) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}

