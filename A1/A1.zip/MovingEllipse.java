/*
 *	===============================================================================
 *	MovingEllipse.java : extends MovingShape and it is the superclass of MovingCircle.
 *	It represents an ellipse object.
 *	It overrides the draw(), getArea() and contains() methods from MovingShape.
 *	Author: Nicholas Tony
 *	UPI: nton939
 *	===============================================================================
 */
 
import java.awt.*;
import java.util.*;

public class MovingEllipse extends MovingShape {
    public MovingEllipse() {
        super();
    }
    public MovingEllipse(int defaultSize) {
        super(defaultSize);
    }
    public MovingEllipse(int x, int y, int w, int h, int mw, int mh, Color bc, Color fc, int pathType) {
        super(x, y, w, h, mw, mh, bc, fc, pathType);
    }
    public void draw(Graphics g) {
		g.setColor(fillColor);
        g.fillOval(x, y, width, height);
		g.setColor(borderColor);
        g.drawOval(x, y, width, height); 
    }
    public double getArea() {
        double a = (width / 2) * (height / 2) * Math.PI;
        return a;
    }
    public boolean contains(Point p) {
        double dx, dy; 
        Point EndPt = new Point(x + width, y + height); 
        dx = (2 * p.x - x - EndPt.x) / (double) width; 
        dy = (2 * p.y - y - EndPt.y) / (double) height; 
        return dx * dx + dy * dy < 1.0;  
    }
}
